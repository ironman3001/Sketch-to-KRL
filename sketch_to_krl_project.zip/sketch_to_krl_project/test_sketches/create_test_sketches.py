import numpy as np
import cv2
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
import os

# Create directory if it doesn't exist
if not os.path.exists('test_sketches'):
    os.makedirs('test_sketches')

# Create a simple square sketch
def create_square_sketch():
    # Create a blank image
    img = np.ones((500, 500, 3), dtype=np.uint8) * 255
    
    # Draw a simple path
    cv2.line(img, (100, 100), (400, 100), (0, 0, 0), 5)
    cv2.line(img, (400, 100), (400, 400), (0, 0, 0), 5)
    cv2.line(img, (400, 400), (100, 400), (0, 0, 0), 5)
    cv2.line(img, (100, 400), (100, 100), (0, 0, 0), 5)
    
    # Add a diagonal line
    cv2.line(img, (100, 100), (400, 400), (0, 0, 0), 5)
    
    # Save the image
    cv2.imwrite('test_sketches/square_with_diagonal.png', img)
    
    return img

# Create a circular path
def create_circle_sketch():
    img = np.ones((500, 500, 3), dtype=np.uint8) * 255
    cv2.circle(img, (250, 250), 200, (0, 0, 0), 5)
    
    # Save the image
    cv2.imwrite('test_sketches/circle.png', img)
    
    return img

# Create a star path
def create_star_sketch():
    img = np.ones((500, 500, 3), dtype=np.uint8) * 255
    pil_img = Image.fromarray(img)
    draw = ImageDraw.Draw(pil_img)
    
    # Draw a star
    points = []
    center_x, center_y = 250, 250
    outer_radius = 200
    inner_radius = 100
    num_points = 5
    
    for i in range(num_points * 2):
        angle = np.pi / num_points * i
        radius = outer_radius if i % 2 == 0 else inner_radius
        x = center_x + radius * np.cos(angle)
        y = center_y + radius * np.sin(angle)
        points.append((x, y))
    
    # Close the shape
    points.append(points[0])
    
    # Draw the star
    draw.line(points, fill=(0, 0, 0), width=5)
    
    # Convert back to numpy array
    img = np.array(pil_img)
    
    # Save the image
    cv2.imwrite('test_sketches/star.png', img)
    
    return img

# Create a zigzag path
def create_zigzag_sketch():
    img = np.ones((500, 500, 3), dtype=np.uint8) * 255
    
    # Draw a zigzag path
    points = [(50, 250)]
    
    for i in range(1, 10):
        x = 50 + i * 50
        y = 250 + (100 if i % 2 == 0 else -100)
        points.append((x, y))
    
    # Draw the zigzag
    for i in range(len(points) - 1):
        cv2.line(img, points[i], points[i+1], (0, 0, 0), 5)
    
    # Save the image
    cv2.imwrite('test_sketches/zigzag.png', img)
    
    return img

# Create a spiral path
def create_spiral_sketch():
    img = np.ones((500, 500, 3), dtype=np.uint8) * 255
    pil_img = Image.fromarray(img)
    draw = ImageDraw.Draw(pil_img)
    
    # Draw a spiral
    points = []
    center_x, center_y = 250, 250
    radius = 10
    num_turns = 5
    points_per_turn = 20
    
    for i in range(num_turns * points_per_turn):
        angle = 2 * np.pi * i / points_per_turn
        r = radius + (i / points_per_turn) * 30
        x = center_x + r * np.cos(angle)
        y = center_y + r * np.sin(angle)
        points.append((x, y))
    
    # Draw the spiral
    draw.line(points, fill=(0, 0, 0), width=5)
    
    # Convert back to numpy array
    img = np.array(pil_img)
    
    # Save the image
    cv2.imwrite('test_sketches/spiral.png', img)
    
    return img

# Create all test sketches
square_img = create_square_sketch()
circle_img = create_circle_sketch()
star_img = create_star_sketch()
zigzag_img = create_zigzag_sketch()
spiral_img = create_spiral_sketch()

# Display the test sketches
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(cv2.cvtColor(square_img, cv2.COLOR_BGR2RGB))
plt.title('Square with Diagonal')
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(cv2.cvtColor(circle_img, cv2.COLOR_BGR2RGB))
plt.title('Circle')
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(cv2.cvtColor(star_img, cv2.COLOR_BGR2RGB))
plt.title('Star')
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(cv2.cvtColor(zigzag_img, cv2.COLOR_BGR2RGB))
plt.title('Zigzag')
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(cv2.cvtColor(spiral_img, cv2.COLOR_BGR2RGB))
plt.title('Spiral')
plt.axis('off')

plt.tight_layout()
plt.savefig('test_sketches/all_test_sketches.png')
plt.close()

print("Test sketches created successfully!")